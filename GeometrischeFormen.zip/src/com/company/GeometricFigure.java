package com.company;

public abstract class GeometricFigure {

    // Methodes
    public abstract void calculateArea();
}
