package com.company;

public class Rectangle extends GeometricFigure {

    // Variables
    double a;
    double b;

    // Constructor
    public Rectangle(double a, double b) {
        this.a = a;
        this.b = b;
    }

    // Methodes
    @Override
    public void calculateArea() {
        System.out.println("Area of Rectangle: " + (a * b));
    }
}
