package com.company;

public class Main {

    public static void main(String[] args) {

        // Instances
        Square testSquare = new Square(25);
        Rectangle testRectangle = new Rectangle(20,25);

        // testing functions
        testSquare.calculateArea();
        testRectangle.calculateArea();
    }
}
