package com.company;

public class Square extends GeometricFigure {

    // Variables
    double a;

    // Constructor
    public Square(double a) {
        this.a = a;
    }

    // Methodes
    @Override
    public void calculateArea() {
        System.out.println("Area of Square: " + (a * a));
    }
}
